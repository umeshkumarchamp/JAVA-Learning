package app.Spring1;

public class HDFC implements RBI {

	public void debit() {
		System.out.println("Debit using HDFC Bank");
	}

	public void creadit() {
		System.out.println("Credit using HDFC Bank");
		
	}

	
	
}
