package app.Spring1;

public class Axis implements RBI{

	public void debit() {
		System.out.println("Debit using Axis Bank");
	}

	public void creadit() {
		System.out.println("Credit using Axis Bank");
		
	}

	
}
