package app.Spring1;

public interface RBI {

	void debit(); 
	void creadit(); 
	
}
