package app.Spring1;

public class SBI implements RBI {

	public void debit() {
		System.out.println("Debit using SBI Bank");
	}

	public void creadit() {
		System.out.println("Credit using SBI Bank");
		
	}

	
	
}
