package app.Spring1;

public class Student {

	private int roll; 
	private String name;
	
//	public Student() {
//		System.out.println("This is Student class.....");
//	}

	public int getRoll() {
		return roll;
	}

	public void setRoll(int roll) {
		this.roll = roll;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	} 
	
	
	
}
