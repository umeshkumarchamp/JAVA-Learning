package app.Spring1;

public class ICICI implements RBI{

	public void debit() {
		System.out.println("Debit using ICICI Bank");
	}

	public void creadit() {
		System.out.println("Credit using ICICI Bank");
		
	}

	
}
